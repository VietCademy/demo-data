<?php
/**
 * Vietcademy Core Plugin.
 * Plugin Name:       Vietcademy Core
 * Plugin URI:        https://vietcademy.vn
 * Description:       Quản lý trang web của bạn dễ dàng hơn với Vietcademy Core.
 * Version:           1.0.1
 * Author: 			  Vietcademy
 * Author URI:        https://vietcademy.vn
 * Text Domain:       vietcademy-core
 * Domain Path:       /languages
 * Tested up to: 6.0
 * Requires PHP: 7.0
 * @package   Vietcademy_Core
 * @since     1.0.0
 * @author    Vietcademy <admin@vietcademy.vn>
 * @link      https://vietcademy.vn
 * @copyright 2025 Vietcademy
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
/**
 * Class TP
 *
 * @since 0.1.0
 */
if ( ! class_exists( 'VCA' ) ) {
	class VCA {
		/**
		 * @var null
		 *
		 * @since 0.1.0
		 */
		protected static $_instance = null;

		/**
		 * @var string
		 *
		 * @since 0.1.0
		 */
		public static $prefix = 'vietcademy_';

		/**
		 * @var string
		 *
		 * @since 0.8.5
		 */
		public static $slug = 'vietcademy-core';

		/**
		 * @var string
		 *
		 * @since 0.2.0
		 */
		private static $option_version = 'vietcademy_core_version';

		/**
		 * Return unique instance of TP.
		 *
		 * @since 0.1.0
		 */
		static function instance() {
			if ( ! self::$_instance ) {
				self::$_instance = new self();
			}

			return self::$_instance;
		}

		/**
		 * Vietcademy_Framework constructor.
		 *
		 * @since 0.1.0
		 */
		private function __construct() {
			$this->init();
			$this->hooks();

			do_action( 'vietcademy_core_loaded' );
		}

		/**
		 * Get is debug?
		 *
		 * @return bool
		 * @since 0.1.0
		 */
		public static function is_debug() {
			if ( ! defined( 'VIETCADEMY_DEBUG' ) ) {
				return false;
			}

			return (bool) VIETCADEMY_DEBUG;
		}

		/**
		 * Init class.
		 *
		 * @since 0.1.0
		 */
		public function init() {
			do_action( 'before_vietcademy_core_init' );

			$this->define_constants();
			$this->providers();

			spl_autoload_register( array( $this, 'autoload' ) );

			$this->inc();
			$this->admin();

			do_action( 'vietcademy_core_init' );
		}

		/**
		 * Define constants.
		 *
		 * @since 0.2.0
		 */
		private function define_constants() {
			$this->define( 'VIETCADEMY_CORE_FILE', __FILE__ );
			$this->define( 'VIETCADEMY_CORE_PATH', dirname( __FILE__ ) );

			$this->define( 'VIETCADEMY_CORE_URI', untrailingslashit( plugins_url( '/', VIETCADEMY_CORE_FILE ) ) );
			$this->define( 'VIETCADEMY_CORE_ASSETS_URI', VIETCADEMY_CORE_URI . '/assets' );

			$this->define( 'VIETCADEMY_CORE_VERSION', '1.0.1' );

			$this->define( 'VIETCADEMY_CORE_ADMIN_PATH', VIETCADEMY_CORE_PATH . '/admin' );
			$this->define( 'VIETCADEMY_CORE_ADMIN_URI', VIETCADEMY_CORE_URI . '/admin' );
			$this->define( 'VIETCADEMY_CORE_INC_PATH', VIETCADEMY_CORE_PATH . '/inc' );
			$this->define( 'VIETCADEMY_CORE_INC_URI', VIETCADEMY_CORE_URI . '/inc' );
		}

		/**
		 * Define constant.
		 *
		 * @param $name
		 * @param $value
		 *
		 * @since 1.0.0
		 *
		 */
		private function define( $name, $value ) {
			if ( ! defined( $name ) ) {
				define( $name, $value );
			}
		}

		/**
		 * Init hooks.
		 *
		 * @since 0.1.0
		 */
		private function hooks() {
			register_activation_hook( __FILE__, array( $this, 'install' ) );
			add_action( 'activated_plugin', array( $this, 'activated' ) );
			add_action( 'plugins_loaded', array( $this, 'text_domain' ), 1 );
		}

		/**
		 * Autoload classes.
		 *
		 * @param $class
		 *
		 * @return bool
		 * @since 1.0.0
		 *
		 */
		public function autoload( $class ) {
			$class = strtolower( $class );

			$file_name = 'class-' . str_replace( '_', '-', $class ) . '.php';

			/**
			 * Helper classes.
			 */
			if ( strpos( $class, 'helper' ) !== false ) {
				$path = VIETCADEMY_CORE_PATH . '/helpers/' . $file_name;

				return $this->_require( $path );
			}

			/**
			 * Inc
			 */
			$path = VIETCADEMY_CORE_INC_PATH . DIRECTORY_SEPARATOR . $file_name;
			if ( is_readable( $path ) ) {
				return $this->_require( $path );
			}

			/**
			 * Admin
			 */
			$path = VIETCADEMY_CORE_ADMIN_PATH . DIRECTORY_SEPARATOR . $file_name;
			if ( is_readable( $path ) ) {
				return $this->_require( $path );
			}

			return false;
		}

		/**
		 * Require file.
		 *
		 * @param $path
		 *
		 * @return bool
		 * @since 1.0.5
		 *
		 */
		private function _require( $path ) {
			if ( ! is_readable( $path ) ) {
				return false;
			}

			require_once $path;

			return true;
		}

		/**
		 * Providers.
		 *
		 * @since 0.8.5
		 */
		private function providers() {
			require_once VIETCADEMY_CORE_PATH . '/providers/class-vietcademy-singleton.php';
		}

		/**
		 * Core.
		 *
		 * @since 0.1.0
		 */
		private function inc() {
			require_once VIETCADEMY_CORE_INC_PATH . '/class-vietcademy-core.php';
		}

		/**
		 * Admin.
		 *
		 * @since 0.1.0
		 */
		private function admin() {
			require_once VIETCADEMY_CORE_PATH . '/admin/class-vietcademy-core-admin.php';
		}

		/**
		 * Activation hook.
		 *
		 * @since 0.2.0
		 */
		public function install() {
			add_option( self::$option_version, VIETCADEMY_CORE_VERSION );

			do_action( 'vietcademy_core_activation' );
		}

		/**
		 * Hook after plugin was activated.
		 *
		 * @param $plugin
		 *
		 * @since 0.2.0
		 *
		 */
		public function activated( $plugin ) {
			$plugins_are_activating = isset( $_POST['checked'] ) ? $_POST['checked'] : array();

			if ( count( $plugins_are_activating ) > 1 ) {
				return;
			}

			if ( 'vietcademy-core/vietcademy-core.php' !== $plugin ) {
				return;
			}

			Vietcademy_Core_Admin::go_to_theme_dashboard();
		}

		/**
		 * Get active network.
		 *
		 * @return bool
		 * @since 0.8.1
		 *
		 */
		public static function is_active_network() {
			if ( ! is_multisite() ) {
				return true;
			}

			$plugin_file            = 'vietcademy-core/vietcademy-core.php';
			$active_plugins_network = get_site_option( 'active_sitewide_plugins' );

			if ( isset( $active_plugins_network[$plugin_file] ) ) {
				return true;
			}

			return false;
		}

		/**
		 * Load text domain.
		 *
		 * @since 0.1.0
		 *
		 */
		function text_domain() {
			// Get the current locale of the site
			$locale = apply_filters( 'plugin_locale', get_locale(), 'vietcademy-core' );

			// Check if the locale is Vietnamese (vi)
			if ( $locale === 'vi' ) {
				// Load the Vietnamese translation file from the plugin's languages folder
				load_textdomain(
					'vietcademy-core',
					plugin_dir_path( __FILE__ ) . 'languages/vietcademy-core-vi.mo'
				);
			}

			// Load custom translation file from WP_LANG_DIR (if available)
			load_textdomain(
				'vietcademy-core',
				trailingslashit( WP_LANG_DIR ) . 'vietcademy-core' . '/' . 'vietcademy-core-' . $locale . '.mo'
			);

			// Load default translation file from the plugin's languages folder
			load_plugin_textdomain(
				'vietcademy-core', false,
				basename( plugin_dir_path( dirname( __FILE__ ) ) ) . '/languages/'
			);
		}
	}

	VCA::instance();
}// End if().
