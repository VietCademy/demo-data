=== Vietcademy Core ===
Contributors: Vietcademy
Donate link: https://vietcademy.vn
Tags: admin, customize, framework
Requires at least: 4.8
Tested up to: 5.8
Stable tag: 1.0.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

The Ultimate Core Processor of all WordPress themes by Vietcademy - Manage your website easier with Vietcademy Core.

== Description ==

Vietcademy Core is a Core Processor of all **WordPress themes by Vietcademy** and it is meant to be used only with VietcademyCode's WordPress themes.

# What themes does Vietcademy Core support
- [Vietcademy](https://demo.vietcademy.vn): The best theme for education, online teaching, LMS...
- Register necessary custom post types, custom fields for the themes
- Add a Control Panel, Customization Page to easier manage the theme
- Works as a One-Click Installer to install WordPress themes easier

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/vietcademy-core` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Read our guide on how to Get Started with Vietcademy Core.


== Frequently Asked Questions ==


== Screenshots ==


== Changelog ==

= 1.0.0 =
- The most amazing Vietcademy Core plugin was born.
