<?php
$body_template = 'boxes/' . $args['template'] . '.php';
$locked        = $args['lock'] && ! Vietcademy_Product_Registration::is_active();
$box_id        = isset( $args['id'] ) ? $args['id'] : '';
$class_extend  = apply_filters( 'vietcademy_core_dashboard_box_classes', '', $box_id );
$class_extend  .= isset( $args['class'] ) ? $args['class'] : '';
$themes_active = Vietcademy_Theme_Manager::get_metadata();
?>

<div class="tc-box<?php echo esc_attr( $locked ? ' locked' : '' ); ?> <?php echo esc_attr( $class_extend ); ?>"
	 data-id="<?php echo esc_attr( $args['id'] ); ?>">
	<div class="tc-box-header">
		<?php
		if ( $args['lock'] ) {
			Vietcademy_Dashboard::get_template( 'partials/box-status.php' );
		}
		?>
		<h2 class="box-title"><?php echo esc_html( $args['title'] ); ?></h2>
		<?php if ( $args['id'] == 'appearance' ) {
			$link = wp_customize_url();
			echo '<a href="' . $link . '" class="sub_link" target="_blank">' . __( 'Go to Theme Settings', 'vietcademy-core' ) . '</a>';
		}
		if ( $args['id'] == 'changelog' && $args['links'] ) {
			echo '<a href="' . esc_url( $args['links'] ) . '" class="sub_link" target="_blank">' . __( 'View all Changelog', 'vietcademy-core' ) . '</a>';
		}
		?>
	</div>

	<?php Vietcademy_Dashboard::get_template( $body_template ); ?>
</div>
