<?php
$theme_metadata = Vietcademy_Theme_Manager::get_metadata();
$theme_name     = $theme_metadata['name'];
?>

<div class="top">
    <h2><?php esc_html_e( 'Import Demo Content', 'vietcademy-core' ); ?></h2>

    <div class="caption">
        <p><?php esc_html_e( 'You are almost done!', 'vietcademy-core' ); ?></p>
        <p><?php esc_html_e( 'Please choose a demo content that you like the most. These demos are all amazing, so it may take you a while to choose and a little more time to install.', 'vietcademy-core' ); ?></p>
    </div>

	<?php
	do_action( 'vietcademy_dashboard_main_page_importer' );
	do_action( 'vietcademy_importer_modals' );
	?>
</div>

<div class="bottom">
    <a class="tc-skip-step"><?php esc_html_e( 'Skip', 'vietcademy-core' ); ?></a>
    <button class="button button-primary tc-button tc-run-step"><?php esc_html_e( 'Next step →', 'vietcademy-core' ); ?></button>
</div>
