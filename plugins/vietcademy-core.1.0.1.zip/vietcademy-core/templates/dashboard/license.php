<?php
$license_key    = Vietcademy_Product_Registration::get_data_theme_register( 'license_key' );
$find_licence   = 'https://vietcademy.vn/tai-khoan/don-hang/';

$is_active  = Vietcademy_Product_Registration::is_active();
?>

<div class="tc-box tc-box-theme-license">
	<div class="tc-box-header">
		<h2 class="box-title">
			<?php esc_html_e( 'Activate your theme license', 'vietcademy-core' ); ?>
		</h2>
	</div>

	<div class="tc-box-body">
		<?php
		if ( $is_active ) :
 				?>
				<div class="wrapper-message">
					<div class="message-success message">
						<?php esc_html_e( 'Your theme license is activated. Thank you!', 'vietcademy-core' ); ?>
					</div>
				</div>
				<table class="form-table">
					<tbody>
						<?php if ( ! empty( $license_key ) && strlen( $license_key ) > 7 ) : ?>
							<tr class="license-active">
								<th scope="row">
									<?php esc_html_e( 'License Key: ', 'vietcademy-core' ); ?>
								</th>
								<td>
									<?php // Show License Key with **** and last 3 characters of the purchase code with format uuid4 ?>
									<input type="text"
										value="<?php echo esc_html( str_repeat( '*', strlen( $license_key ) - 7 ) . substr( $license_key, - 4 ) ); ?>"
										disabled>
									<button
										class="vietcademy-deactive button button-secondary tc-button deactivate-btn tc-run-step">
										<?php esc_html_e( 'Deactivate', 'vietcademy-core' ); ?>
									</button>
								</td>
							</tr>
						<?php endif; ?>
					</tbody>
				</table>
 		<?php else: ?>
			<div class="wrapper-message">
				<div class="message-info message">
					<?php esc_html_e( 'Activate your license key for this domain to turn on install plugin required and import data demo', 'vietcademy-core' ); ?>
				</div>
			</div>

			<form class="vietcademy-form-license" action="" method="post">
				<table class="form-table">
					<tbody>
						<tr>
							<th scope="row">
								<?php esc_html_e( 'License key ', 'vietcademy-core' ); ?>
								<span class="required">*</span>
							</th>
							<td>
								<input type="text" id="license_key" name="license_key" value=""
									placeholder="Enter license key" autocomplete="off" required>
								<p class="find-license"><small>
									<a href="<?php echo esc_url( $find_licence ); ?>" target="_blank" rel="noopener">
										<?php esc_html_e( 'Where can I get my license key', 'vietcademy-core' ); ?>
									</a></small>
								</p>
							</td>
						</tr>
					</tbody>
				</table>
				<p>
					<label for="agree_stored" class="agree-label">
						<input type="checkbox" name="agree_stored" id="agree_stored" required>
						<?php echo sprintf( esc_html__( 'I agree that my purchase code and user data will be stored by %s.', 'vietcademy-core' ), '<a href="https://vietcademy.vn" target="_blank">' . 'Vietcademy.vn' . '</a>' ); ?>
					</label>
				</p>

				<input type="hidden" name="url" value="<?php echo esc_url( site_url() ); ?>">

				<button class="button button-primary tc-button activate-btn tc-run-step" type="submit">
					<?php esc_html_e( 'Submit', 'vietcademy-core' ); ?>
				</button>
			</form>
		<?php endif; ?>

	</div>
	<div class="tc-box-footer">
		<p style="color: red;">
			<?php echo sprintf( esc_html__( 'Note: Each license key is valid for one domain only. If you want to install this theme on another domain, please purchase additional WordPress solutions at %s.', 'vietcademy-core' ), '<a href="https://vietcademy.vn/wordpress" target="_blank">' . 'Vietcademy.vn' . '</a>' ); ?>
		</p>
	</div>
</div>
