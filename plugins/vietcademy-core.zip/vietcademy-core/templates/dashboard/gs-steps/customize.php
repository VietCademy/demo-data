<?php
$theme_metadata  = Vietcademy_Theme_Manager::get_metadata();
$links           = $theme_metadata['links'];
$name_keys = apply_filters('vietcademy_name_theme_panel_active_customize', $theme_metadata['name']);

?>

<div class="top">
    <div class="row">
        <div class="col-md-12">
            <h2><?php esc_html_e( 'Settings Your Site', 'vietcademy-core' ); ?></h2>
            <div class="caption no-line">
                <p><?php esc_html_e( 'Congratulations! You are all set!', 'vietcademy-core' ); ?></p>

                <h4><?php esc_html_e( 'What now?', 'vietcademy-core' ); ?></h4>
                <ul class="tc-list">
                    <li><?php esc_html_e( 'You should edit the content of the web to fit your business purpose (update images, articles...).', 'vietcademy-core' ); ?></li>
                    <li><?php esc_html_e( 'You should customize your website to make it fit your idea, using the advanced customize system of the theme.', 'vietcademy-core' ); ?></li>
                    <li><?php esc_html_e( 'Watch this video tutorial to learn how to use the Customize system and how to edit the theme easily.', 'vietcademy-core' ); ?></li>
                </ul>
            </div>
        </div>
    </div>
</div>

<div class="bottom">
    <a class="tc-skip-step"><?php esc_html_e( 'Skip', 'vietcademy-core' ); ?></a>
    <a href="<?php echo esc_url( admin_url( 'customize.php' ) ); ?>"
       class="button button-primary tc-button tc-run-step">
		<?php esc_html_e( 'Settings your site', 'vietcademy-core' ); ?>
    </a>
</div>

