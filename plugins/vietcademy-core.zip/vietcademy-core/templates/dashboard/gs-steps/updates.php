<div class="top">
    <h2><?php esc_html_e( 'Theme Updates', 'vietcademy-core' ); ?></h2>

    <div class="caption no-line">
        <p><?php esc_html_e( 'To improve the quality of the theme and to fix bugs, we frequently update our theme. Therefore, we highly recommend you to enable automatic theme update function.', 'vietcademy-core' ); ?></p>
        <p><?php esc_html_e( 'When there is a new update, your Dashboard will display a message with the option to install the new update.', 'vietcademy-core' ); ?></p>
        <p><?php esc_html_e( 'Please', 'vietcademy-core' ); ?> <a href="https://vietcademy.vn" target="_blank"><?php esc_html_e( 'contact us', 'vietcademy-core' ); ?></a> <?php esc_html_e( 'if you have any questions or problems.', 'vietcademy-core' ); ?></p>
     </div>
</div>

<div class="bottom">
	<a class="tc-skip-step"><?php esc_html_e( 'Skip', 'vietcademy-core' ); ?></a>
    <?php
    $return = Vietcademy_Getting_Started::get_link_redirect_step( 'install-plugins' );
    Vietcademy_Dashboard::get_template(
        'partials/button-activate.php',
        array(
            'return' => $return,
        )
    );
    ?>
</div>
