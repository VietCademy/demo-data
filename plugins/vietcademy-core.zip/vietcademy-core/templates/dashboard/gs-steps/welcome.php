<?php
$theme_metadata = Vietcademy_Theme_Manager::get_metadata();
$theme_name     = $theme_metadata['name'];
$links          = $theme_metadata['links'];
$docs           = $links['docs'];
$support        = $links['support'];
?>

<div class="top">
    <div class="row">
        <div class="col-md-12">
            <h2><?php echo esc_html__( 'Welcome to', 'vietcademy-core' ) . ' ' . esc_html( $theme_name ); ?></h2>

            <div class="caption no-line">
				<?php
				echo '<p>' . esc_html__( 'Hello there,', 'vietcademy-core' ) . '</p>';

				echo '<p>' . sprintf(
					esc_html__(
						'If this is the first time you work with %1$s, please read and follow the instructions carefully. This is the getting started section of %1$s Theme Dashboard. It involves some simple steps to help you install the theme easier and to show you how the theme works, how to edit and customize the theme as you want it to be.',
						'vietcademy-core'
					),
					esc_html( $theme_name )
				) . '</p>';

				echo '<p>' . sprintf(
					esc_html__(
						'All the documentation and tutorial of the theme can be found %1$shere%2$s. If there\'re any problem with the theme, please create a ticket for our supporters to help you %3$shere%4$s.',
						'vietcademy-core'
					),
					'<a href="' . esc_url( $docs ) . '" target="_blank">', '</a>',
					'<a href="' . esc_url( $support ) . '" target="_blank">', '</a>'
				) . '</p>';

				echo '<p>' . esc_html__( 'Thank you for using the theme.', 'vietcademy-core' ) . '</p>';

				echo '<p>' . esc_html__( 'Now, let\'s start!', 'vietcademy-core' ) . '</p>';

				echo '<div class="shortcuts">';
				echo '<strong>' . esc_html__( 'Keyboard shortcuts:', 'vietcademy-core' ) . '</strong>';
				echo '<ul>';
				echo '<li>' . esc_html__( 'Press', 'vietcademy-core' ) . ' <span class="tc-kbd dashicons dashicons-editor-break"></span> ' . esc_html__( 'to Continue', 'vietcademy-core' ) . '</li>';
				echo '<li>' . esc_html__( 'Press', 'vietcademy-core' ) . ' <span class="tc-kbd dashicons dashicons-arrow-right-alt"></span> ' . esc_html__( 'to Skip', 'vietcademy-core' ) . '</li>';
				echo '<li>' . esc_html__( 'Press', 'vietcademy-core' ) . ' <span class="tc-kbd dashicons dashicons-arrow-left-alt"></span> ' . esc_html__( 'to Go back', 'vietcademy-core' ) . '</li>';
				echo '</ul>';
				echo '</div>';
				?>
			</div>
        </div>
    </div>
</div>

<div class="bottom">
    <a class="tc-skip-step">Skip</a>
    <button class="button button-primary tc-button tc-run-step"><?php esc_html_e( 'Next step →', 'vietcademy-core' ); ?></button>
</div>
