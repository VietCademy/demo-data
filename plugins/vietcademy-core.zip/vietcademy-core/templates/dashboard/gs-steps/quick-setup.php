<div class="top">
    <h2><?php esc_html_e( 'General Setup', 'vietcademy-core' ); ?></h2>

    <div class="caption">
        <p><?php esc_html_e( "Let's do some quick set up for your site!", 'vietcademy-core' ); ?></p>
    </div>

    <form>
        <div class="form-group">
            <label for="blogname"><?php esc_html_e( 'What is the name of your website?', 'vietcademy-core' ); ?></label>
            <input id="blogname" name="blogname" type="text" class="regular-text" value="<?php echo esc_html( get_bloginfo( 'name' ) ); ?>">
        </div>

        <div class="form-group">
            <label for="blogdescription"><?php esc_html_e( 'How would you describe your site?', 'vietcademy-core' ); ?></label>
            <input id="blogdescription" name="blogdescription" type="text" class="regular-text" value="<?php echo esc_html( get_bloginfo( 'description' ) ); ?>">
        </div>
    </form>
</div>

<div class="bottom">
    <a class="tc-skip-step"><?php esc_html_e( 'Skip', 'vietcademy-core' ); ?></a>
    <button class="button button-primary tc-button tc-run-step" data-request="yes"><?php esc_html_e( 'Save', 'vietcademy-core' ); ?></button>
</div>
