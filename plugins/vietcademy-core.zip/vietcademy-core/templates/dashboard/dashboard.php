<div class="tc-dashboard-wrapper wrap">
	<?php
	do_action( 'vietcademy_dashboard_registration_box' );
	?>

	<?php
	do_action( 'vietcademy_dashboard_boxes_content' );
	?>
</div>
