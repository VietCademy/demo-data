<?php

 $url_args = array(
	'page' => 'vietcademy-license',
);

if ( ! empty( $args['return'] ) ) {
	$url_args['vietcademy_redirect'] = urlencode( $args['return'] );
}

$url = add_query_arg( $url_args, admin_url( 'admin.php' ) );
?>
<a class="button button-primary tc-button" href="<?php echo esc_url( $url ); ?>">
	<?php esc_html_e( 'Activate theme', 'vietcademy-core' ); ?>
</a>
