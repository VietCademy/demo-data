<div class="tc-box-body">
	<div class="text-panel-customizer">
		<?php
		/**
		 * Documentation links
		 */
		$customizer_section_default = array(
            'panel'   => array(
                'general'    => __( 'General', 'vietcademy-core' ),
                'widgets'    => __( 'Widgets', 'vietcademy-core' ),
                'nav_menus'  => __( 'Menu', 'vietcademy-core' ),
            ),
            'section' => array(
                'typography' => __( 'Typography', 'vietcademy-core' ),
            ),
        );

		$customizer_section = apply_filters( 'vietcademy_theme_options_section', $customizer_section_default );
		foreach ( $customizer_section as $key => $values ) {
            if ( $values ) {
                foreach ( $values as $value_key => $label ) {
                    echo '<a class="tc-button-box tc-base-color" target="_blank" href="' . wp_customize_url() . '?autofocus[' . $key . ']=' . $value_key . '">' . esc_html( $label ) . '</a>';
                }
            }
        }
		?>
	</div>
</div>
