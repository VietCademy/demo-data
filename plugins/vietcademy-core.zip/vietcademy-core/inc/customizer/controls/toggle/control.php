<?php
namespace PhysCode\Customizer\Control;

defined( 'ABSPATH' ) || exit;

class Toggle extends Checkbox_Switch {

	public $type = 'vietcademy-toggle';
}
