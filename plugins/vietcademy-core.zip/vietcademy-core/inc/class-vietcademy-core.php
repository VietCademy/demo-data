<?php
/**
 * Class Vietcademy_Core
 *
 * @package   Vietcademy_Core
 * @since     0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Class Vietcademy Core.
 *
 * @since 0.1.0
 */
if ( ! class_exists( 'Vietcademy_Core' ) ) {
	class Vietcademy_Core extends Vietcademy_Singleton {
		/**
		 * Vietcademy_Core constructor.
		 *
		 * @since 0.1.0
		 */
		protected function __construct() {
			$this->init_global_variables();
			$this->init();
			$this->run();
		}

		/**
		 * Init global variables.
		 *
		 * @since 0.8.8
		 */
		private function init_global_variables() {
			/**
			 * List notifications in dashboard.
			 */
			global $vietcademy_notifications;
			$vietcademy_notifications = array();
		}

		/**
		 * Init functions.
		 *
		 * @since 0.1.0
		 */
		private function init() {
			$this->includes();
		}

		/**
		 * Run.
		 *
		 * @since 0.5.0
		 */
		private function run() {
			Vietcademy_Notification::instance();
			if ( apply_filters( 'vietcademy-support-customizer', true ) ) {
				Vietcademy_Core_Customizer::instance();
			}
		}

		/**
		 * Include functions.
		 *
		 * @since 0.1.0
		 */
		private function functions() {
			$this->_require( 'functions.php' );
		}

		/**
		 * Include libraries and functions.
		 *
		 * @since 0.1.0
		 */
		private function includes() {
			$this->libraries();
			$this->functions();
		}

		/**
		 * Include libraries.
		 *
		 * @since 0.1.0
		 */
		private function libraries() {
			$this->_require( 'class-vietcademy-breadcrumb.php' );
			$this->_require( 'class-vietcademy-crop-image-size.php' );
			$this->_require( 'class-vietcademy-core-likes-views.php' );
			$this->_require( 'class-tax-meta.php' );
		}


		/**
		 * Require file.
		 *
		 * @param $file
		 *
		 * @since 0.5.0
		 *
		 */
		private function _require( $file ) {
			$path = VIETCADEMY_CORE_INC_PATH . DIRECTORY_SEPARATOR . $file;

 			if ( ! file_exists( $path ) ) {
				return;
			}

			require_once $path;
		}
	}
}

Vietcademy_Core::instance();
