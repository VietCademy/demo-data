(function ($) {
	$(document).ready(function () { 

	});
	$(document).on('click', '.tc-button-deregister', function (e) {
		e.preventDefault();
		var confirm = window.confirm($(this).data('confirm_deregister'));
		if (!confirm) {
			return;
		}

		window.location.href = $(this).data('url-deregister');
	});
})(jQuery);


function physActivatePlugin() {
	const form = document.querySelector('.vietcademy-form-license');
	let wrapper = document.querySelector('.wrapper-message');
	if (form) {
		form.addEventListener('submit', function (e) {
			e.preventDefault();

			// remove all notice
			const notices = document.querySelectorAll('.vietcademy-license-notice');
			notices.forEach(function (notice) {
				notice.remove();
			});

			//Get all form data values
			const formData = new FormData(form);

			//Get the form values
			const data = {};

			for (const [key, value] of formData.entries()) {
				data[key] = value;
			}

			const btn = form.querySelector('[type="submit"]'),
				btnText = btn.innerHTML;

			btn.innerHTML = 'Activating...';

			btn.setAttribute('disabled', 'disabled');

			// Use wp.apiFetch to POST to the REST API
			wp.apiFetch({
				path: '/vietca-market/v1/license/activate',
				method: 'POST',
				data: data,
			}).then((response) => {
				// add message after form use insertAdjacentHTML.
				if ( response.status == 'success' ) {
					// form.insertAdjacentHTML('afterend', '<div class="vietcademy-license-notice vietcademy-license-notice--success text-success"><p>License activated successfully.</p></div>');
					wrapper.innerHTML = '<div class="vietcademy-license-notice message-success text-success message">License activated successfully.</div>';

					setTimeout(function () {
						// Get param 'vietcademy_redirect' from url and redirect to that url.
						const urlParams = new URLSearchParams(window.location.search);
						let redirect_url = urlParams.get('vietcademy_redirect');

						if ( redirect_url ) {
							window.location.href = redirect_url;
						} else {
							window.location.reload();
						}
					}, 800);
				} else {
					// form.insertAdjacentHTML('afterend', '<div class="vietcademy-license-notice vietcademy-license-notice--error text-error"><p>' + response.message + '</p></div>');
					wrapper.innerHTML = '<div class="vietcademy-license-notice message-notice message text-error">' + response.message + '</div>';

				}
			}).catch((error) => {
				// add message after form use error.message.
				// form.insertAdjacentHTML('afterend', '<div class="vietcademy-license-notice vietcademy-license-notice--error text-error"><p>' + error.message + '</p></div>');
				wrapper.innerHTML = '<div class="vietcademy-license-notice message-notice message text-error">' + error.message + '</div>';

			}).finally(() => {
				// remove disable attribute to button
				btn.removeAttribute('disabled');
				btn.innerHTML = btnText;
			});
		});
	}
}

function physDeactivatePlugin() {
	const deactivateBtn = document.querySelector('.vietcademy-deactive');

	if (deactivateBtn) {
		deactivateBtn.addEventListener('click', function (e) {
			e.preventDefault();

			// remove all notice
			const notices = document.querySelectorAll('.vietcademy-license-notice');
			notices.forEach(function (notice) {
				notice.remove();
			});

			const btnText = deactivateBtn.innerHTML;

			deactivateBtn.innerHTML = 'Deactivating...';

			deactivateBtn.setAttribute('disabled', 'disabled');

			// Use wp.apiFetch to POST to the REST API
			wp.apiFetch({
				path: '/vietca-market/v1/license/deactivate',
				method: 'POST'
			}).then((response) => {
				// add message after form use insertAdjacentHTML.
				if ( response.status == 'success' ) {
					deactivateBtn.insertAdjacentHTML('afterend', '<div class="vietcademy-license-notice vietcademy-license-notice--success text-success"><p>License deactivated successfully.</p></div>');

					setTimeout(function () {
						window.location.reload();
					}, 800);
				} else {
					deactivateBtn.insertAdjacentHTML('afterend', '<div class="vietcademy-license-notice vietcademy-license-notice--error text-error"><p>' + response.message + '</p></div>');
				}
			}).catch((error) => {
				// add message after form use error.message.
				deactivateBtn.insertAdjacentHTML('afterend', '<div class="vietcademy-license-notice vietcademy-license-notice--error text-error"><p>' + error.message + '</p></div>');
			}).finally(() => {
				// remove disable attribute to button
				deactivateBtn.removeAttribute('disabled');
				deactivateBtn.innerHTML = btnText;
			});
		});
	}
}

document.addEventListener('DOMContentLoaded', function () {
	physActivatePlugin();
	physDeactivatePlugin();
});
