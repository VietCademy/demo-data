<?php

/**
 * Class Vietcademy_Admin_Config
 *
 * @since 1.1.0
 */
class Vietcademy_Admin_Config extends Vietcademy_Singleton {
	/**
	 * @since 1.1.0
	 *
	 * @var null
	 */
	private static $configs = null;

	/**
	 * Vietcademy_Admin_Config constructor.
	 */
	protected function __construct() {
		$this->set_config();
	}

	/**
	 * Set configs.
	 *
	 * @since 1.1.0
	 */
	private function set_config() {
		self::$configs = array(
			'api_check_self_update' => 'https://vietcademy.github.io/demo-data/update-check.json',
			'api_update_plugins'    => 'https://updates.physcode.com/wp-json/thim_em/v1/plugins',
			'api_vietcademy_market' => 'https://vietcademy.vn/wp-json/vietca-market/v1',
			'host_downloads'        => 'https://updates.physcode.com/thim-envato-market',
			'welcome_panel_remote'  => 'https://thimpresswp.github.io/thim-core/newsfeed.json',
			'demo_data'             => 'https://vietcademy.github.io/demo-data/',
			'host_downloads_api'    => 'https://updates.physcode.com/',
		);
	}

	/**
	 * Get config by key.
	 *
	 * @since 1.1.0
	 *
	 * @param      $key
	 * @param null $default
	 *
	 * @return mixed|null
	 */
	public static function get( $key, $default = null ) {
		if ( ! isset( self::$configs[ $key ] ) ) {
			return $default;
		}

		return apply_filters( "vietcademy_core_ac_$key", self::$configs[ $key ] );
	}
}
