<?php

/**
 * Class Vietcademy_Product_Registration.
 *
 * @package   Vietcademy_Core
 * @since     0.2.1
 */
class Vietcademy_Product_Registration extends Vietcademy_Singleton {
	/**
	 * @since 0.2.1
	 *
	 * @var string
	 */
	public static $key_callback_request = 'tc_callback_registration';

	/**
	 * Premium themes.
	 *
	 * @since 0.9.0
	 *
	 * @var null
	 */
	private static $themes = null;

	/**
	 * Deregister product registration.
	 *
	 * @return true|WP_Error
	 * @since 1.5.0
	 *
	 */
	public static function deregister() {
		if ( ! self::is_active() ) {
			return true;
		}

		$allow_deregister = apply_filters( 'vietcademy_core_allow_deregister_activation', true );
		if ( ! $allow_deregister ) {
			return new WP_Error( 'not_allowed', __( 'Can not deregister activation.', 'vietcademy-core' ) );
		}

		self::destroy_active();

		return true;
	}

	/**
	 * Double check theme update before inject update theme.
	 *
	 * @since 1.1.1
	 */
	public static function double_check_theme_update() {
		$instance = self::instance();

		$instance->check_theme_update( true );
	}

	/**
	 * Get product registration data.
	 *
	 * @return array();
	 * @since 0.9.0
	 *
	 */
	public static function get_themes() {
		if ( self::$themes === null ) {
			self::$themes = get_site_option( 'vietcademy_core_product_registration_themes' );
		}

		self::$themes = (array) self::$themes;

		foreach ( self::$themes as $key => $theme ) {
			if ( is_numeric( $key ) ) {
				unset( self::$themes[$key] );
			}
		}

		return self::$themes;
	}

	/**
	 * Set product registration data.
	 *
	 * @param array $data
	 *
	 * @since 0.9.0
	 *
	 */
	private static function _set_themes( $data = array() ) {
		self::$themes = $data;

		update_site_option( 'vietcademy_core_product_registration_themes', $data );
	}

	/**
	 * Get registration data by theme.
	 *
	 * @param       $field
	 * @param null  $theme
	 * @param mixed $default
	 *
	 * @return mixed
	 * @since 0.9.0
	 *
	 */
	public static function get_data_by_theme( $field, $default = false, $theme = null ) {

		if ( ! $theme ) {
			$theme = Vietcademy_Theme_Manager::get_current_theme();
		}

		$registration_data = self::get_themes();

		if ( ! $registration_data ) {
			return $default;
		}

		$theme_data = isset( $registration_data[$theme] ) ? $registration_data[$theme] : false;
		if ( ! $theme_data ) {
			return $default;
		}

		return isset( $theme_data[$field] ) ? $theme_data[$field] : $default;
	}

	/**
	 * Get filed data by theme.
	 *
	 * @param $theme
	 * @param $field
	 * @param $value
	 *
	 * @since 0.9.0
	 *
	 */
	public static function set_data_by_theme( $field, $value, $theme = null ) {
		if ( ! $theme ) {
			$theme = Vietcademy_Theme_Manager::get_current_theme();
		}

		$registration_data = self::get_themes();

		$theme_data         = isset( $registration_data[$theme] ) ? $registration_data[$theme] : array();
		$theme_data         = (array) $theme_data;
		$theme_data[$field] = $value;

		$registration_data[$theme] = $theme_data;

		self::_set_themes( $registration_data );
	}


	/**
	 * data_theme_register.
	 *
	 * @param $stylesheet
	 *
	 * @return bool|string
	 * @since 0.7.0
	 *
	 */
	public static function get_data_theme_register( $key, $stylesheet = null ) {
		$option = self::get_data_by_theme( $key, false, $stylesheet );

		return $option;
	}

	public static function save_data_theme_register_key( $key, $value ) {
		self::set_data_by_theme( $key, $value );
	}


	/**
	 * Get active theme.
	 *
	 * @return bool
	 * @since 0.2.1
	 *
	 */
	public static function is_active() {
		$license_key = self::get_data_theme_register( 'license_key' );
		$is_active   = '';

		if ( $license_key ) {
			$is_active = ! empty( $license_key );
		}

		return $is_active;
	}

	/**
	 * Destroy active theme.
	 *
	 * @since 0.8.0
	 */
	public static function destroy_active() {
		if ( self::get_data_theme_register( 'license_key' ) ) {
			self::save_data_theme_register_key( 'license_key', false );
		} else {
			delete_option( 'vietcademy_core_product_registration_themes' );
		}
	}


	/**
	 * Get url link download theme.
	 *
	 * @param $stylesheet
	 *
	 * @return WP_Error|string
	 * @since 0.7.0
	 *
	 */


	public static function get_url_download_theme( $theme_name = null ) {
		$url_download         = '';
		$license_key = Vietcademy_Product_Registration::get_data_theme_register( 'license_key' );
		if ( $license_key ) {
 			$url_api = Vietcademy_Admin_Config::get( 'api_vietcademy_market' ) . '/download-plugin/';
			$url_download = add_query_arg(
				array(
					'plugin'      => $theme_name,
					'license_key' => $license_key,
				),
				$url_api
			);
		}

		return apply_filters( 'vietcademy_core_get_link_download_theme', $url_download );

	}

	/**
	 * Vietcademy_Product_Registration constructor.
	 *
	 * @since 0.2.1
	 */
	protected function __construct() {
		$this->init_hooks();
		$this->upgrader();
	}

	/**
	 * Upgrader.
	 *
	 * @since 0.9.0
	 */
	private function upgrader() {
		Vietcademy_Auto_Upgrader::instance();
	}

	/**
	 * Init hooks.
	 *
	 * @since 0.2.1
	 */
	private function init_hooks() {
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
		add_action( 'wp_ajax_vietcademy_core_update_theme', array( $this, 'ajax_update_theme' ) );
		add_action( 'vietcademy_core_background_check_update_theme', array( $this, 'background_check_update_theme' ), 1 );
		add_action( 'vietcademy_core_list_modals', array( $this, 'add_modal_activate_theme' ) );
		add_action( 'vietcademy_core_dashboard_init', array( $this, 'handle_deregister' ) );
		add_action( 'template_redirect', array( $this, 'handle_connect_check_activation' ) );
	}

	/**
	 * Handle request check activation.
	 *
	 * @since 1.4.10
	 */
	public function handle_connect_check_activation() {
		$check = isset( $_REQUEST['vietcademy-core-check-activation'] );

		if ( ! $check ) {
			return;
		}

		if ( ! self::is_active() ) {
			wp_send_json_error(
				__( 'Site has not been activate theme.', 'vietcademy-core' )
			);
		}

		wp_send_json_success( __( 'Ok!', 'vietcademy-core' ) );
	}

	/**
	 * Handle deregister.
	 *
	 * @since 1.4.2
	 */
	public function handle_deregister() {
		if ( ! isset( $_REQUEST['vietcademy-core-deregister'] ) ) {
			return;
		}

		$result = self::deregister();

		if ( is_wp_error( $result ) ) {
			$link = Vietcademy_Dashboard::get_link_main_dashboard();
			$link = add_query_arg(
				array(
					'vietcademy-core-error' => $result->get_error_code(),
				),
				$link
			);
			vietcademy_core_redirect( $link );

			return;
		}

		$link = Vietcademy_Dashboard::get_link_main_dashboard();
		vietcademy_core_redirect( $link );
	}

	/**
	 * Add modal activate theme.
	 *
	 * @since 1.3.4
	 */
	public function add_modal_activate_theme() {
		if ( self::is_active() ) {
			return;
		}

		Vietcademy_Modal::render_modal( array(
			'id'       => 'tc-modal-activate-theme',
			'template' => 'registration/activate-modal.php',
		) );
	}

	/**
	 * Handle ajax update theme.
	 *
	 * @since 1.1.0
	 */
	public function ajax_update_theme() {
		check_ajax_referer( 'vietcademy_core_update_theme', 'nonce' );

		$theme_data = Vietcademy_Theme_Manager::get_metadata();
		$theme      = $theme_data['template'];

		include_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
		$skin     = new WP_Ajax_Upgrader_Skin();
		$upgrader = new Theme_Upgrader( $skin );
		$results  = $upgrader->bulk_upgrade( array( $theme ) );
		$messages = $skin->get_upgrade_messages();

		if ( ! $results || ! isset( $results[$theme] ) ) {
			wp_send_json_error( $messages );
		}

		$result = $results[$theme];
		if ( ! $result ) {
			wp_send_json_error( array( __( 'Something went wrong! Please try again later.', 'vietcademy-core' ) ) );
		}

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( $result->get_error_messages() );
		}

		$theme_data = Vietcademy_Theme_Manager::get_metadata( true );
		$theme      = $theme_data['version'];

		wp_send_json_success( $theme );
	}

	/**
	 * Check update theme in background.
	 *
	 * @since 1.1.0
	 */
	public function background_check_update_theme() {
		$force = isset( $_GET['force-check'] );

		$this->check_theme_update( $force );
	}

	/**
	 * Get check update themes.
	 *
	 * @return array
	 * @since 1.1.0
	 *
	 */
	public static function get_update_themes() {
		$update = get_option( 'vietcademy_core_check_update_themes', array() );

		return wp_parse_args( $update, array(
			'last_checked' => false,
			'themes'       => array(),
		) );
	}

	/**
	 * Check update theme.
	 *
	 * @param $force bool
	 *
	 * @since 1.1.0
	 *
	 */
	private function check_theme_update( $force = false ) {
		$update_themes = self::get_update_themes();
		$last_checked  = $update_themes['last_checked'];
		$now           = time();
		$timeout       = 12 * 3600;

		if ( ! $force && $last_checked && $now - $last_checked < $timeout ) {
			return;
		}

		$theme_data      = Vietcademy_Theme_Manager::get_metadata();
		$slug            = $theme_data['text_domain'];
		$current_version = $theme_data['version'];

		$checker                       = new Vietcademy_Check_Update_Theme( $slug, $current_version );
		$update_themes['last_checked'] = $now;
		$data                          = $checker->get_theme_data();

		$themes   = (array) $update_themes['themes'];
		$template = $theme_data['template'];
		if ( $data ) {
			$themes[$template] = array(
				'update'      => '',
				'theme'       => $template,
				'name'        => $data[0]['name'],
				'description' => $data[0]['description'],
				'version'     => $data[0]['version'],
				'author'      => $data[0]['author'],
				'author_url'  => $data[0]['author_profile'],
				'url'         => $data[0]['homepage'],
				'package'     => $data[0]['download_link'],
			);
		} else {
			unset( $themes[$template] );
		}

		$update_themes['themes'] = $themes;

		update_option( 'vietcademy_core_check_update_themes', $update_themes );
	}

	/**
	 * Enqueue scripts.
	 *
	 * @param $page_now
	 *
	 * @since 0.7.0
	 */
	public function enqueue_scripts( $page_now ) {
		if ( strpos( $page_now, Vietcademy_Dashboard::$prefix_slug . 'dashboard' ) === false ) {
			return;
		}

		wp_enqueue_script( 'vietcademy-theme-update', VIETCADEMY_CORE_ADMIN_URI . '/assets/js/theme-update.js', array( 'jquery' ), VIETCADEMY_CORE_VERSION );

		$this->_localize_script();
	}

	/**
	 * Localize script.
	 *
	 * @since 0.7.0
	 */
	private function _localize_script() {
		$nonce           = wp_create_nonce( 'vietcademy_core_update_theme' );
		$link_deregister = Vietcademy_Dashboard::get_link_main_dashboard(
			array(
				'vietcademy-core-deregister' => true,
			)
		);

		wp_localize_script( 'vietcademy-theme-update', 'vietcademy_theme_update', array(
			'admin_ajax'     => admin_url( 'admin-ajax.php' ),
			'action'         => 'vietcademy_core_update_theme',
			'nonce'          => $nonce,
			'url_deregister' => $link_deregister,
			'i18l'           => array(
				'confirm_deregister' => __( 'Are you sure to remove theme activation??', 'vietcademy-core' ),
				'updating'           => __( 'Updating...', 'vietcademy-core' ),
				'updated'            => __( 'Theme is up to date', 'vietcademy-core' ),
				'wrong'              => __( 'Some thing went wrong. Please try again later!', 'vietcademy-core' ),
				'warning_leave'      => __( 'The update process will cause errors if you leave this page!', 'vietcademy-core' ),
				'text_version'       => __( 'Your Version is', 'vietcademy-core' ),
			),
		) );
	}

}
